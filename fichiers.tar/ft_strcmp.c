/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amerle <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/08/19 12:03:52 by amerle            #+#    #+#             */
/*   Updated: 2013/08/19 12:51:35 by amerle           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	int len;

	len = 0;
	while (str[len] != 0)
		len++;
	return (len);
}

int		ft_cmpchar(char c1, char c2)
{
	if (c1 < c2)
		return (-1);
	else
		return (1);
}

int		ft_strcmp(char *s1, char *s2)
{
	int len_s1;
	int len_s2;
	int i;

	if (s1 == 0 || s2 == 0)
		return (-1000);
	len_s1 = ft_strlen(s1);
	len_s2 = ft_strlen(s2);
	if (len_s1 > len_s2)
		return (1);
	else if (len_s1 < len_s2)
		return (-1);
	else
	{
		i = 0;
		while (i < len_s1)
		{
			if (s1[i] != s2[i])
				return (ft_cmpchar(s1[i], s2[i]));
			++i;
		}
		return (0);
	}
}
